from flask import Flask, render_template, request, redirect, url_for, flash, session
import sqlite3
from functools import wraps
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "change-this-secret-key"
DB = "ewaste.db"

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user'
        );
        CREATE TABLE IF NOT EXISTS pickups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL, item TEXT NOT NULL,
            quantity INTEGER NOT NULL, address TEXT NOT NULL,
            pickup_date TEXT NOT NULL, notes TEXT,
            status TEXT NOT NULL DEFAULT 'Pending',
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
        );
        """)
        admin = db.execute("SELECT id FROM users WHERE email=?", ("admin@ewaste.local",)).fetchone()
        if not admin:
            db.execute("INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)",
                       ("Administrator", "admin@ewaste.local",
                        generate_password_hash("Admin@123"), "admin"))

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

def admin_required(fn):
    @wraps(fn)
    @login_required
    def wrapper(*args, **kwargs):
        if session.get("role") != "admin":
            flash("Administrator access is required.", "danger")
            return redirect(url_for("dashboard"))
        return fn(*args, **kwargs)
    return wrapper

@app.route("/")
def index():
    with get_db() as db:
        total = db.execute("SELECT COUNT(*) FROM pickups").fetchone()[0]
        completed = db.execute("SELECT COUNT(*) FROM pickups WHERE status='Recycled'").fetchone()[0]
    return render_template("index.html", total=total, completed=completed)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not name or not email or len(password) < 6:
            flash("Enter all details. Password must contain at least 6 characters.", "danger")
        else:
            try:
                with get_db() as db:
                    db.execute("INSERT INTO users(name,email,password) VALUES(?,?,?)",
                               (name, email, generate_password_hash(password)))
                flash("Account created. Please log in.", "success")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("That email address is already registered.", "danger")
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        with get_db() as db:
            user = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if user and check_password_hash(user["password"], password):
            session.update(user_id=user["id"], name=user["name"], role=user["role"])
            flash("Welcome back!", "success")
            return redirect(url_for("admin" if user["role"] == "admin" else "dashboard"))
        flash("Invalid email or password.", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("index"))

@app.route("/dashboard")
@login_required
def dashboard():
    with get_db() as db:
        rows = db.execute("SELECT * FROM pickups WHERE user_id=? ORDER BY id DESC",
                          (session["user_id"],)).fetchall()
    return render_template("dashboard.html", pickups=rows)

@app.route("/request-pickup", methods=["GET", "POST"])
@login_required
def request_pickup():
    if request.method == "POST":
        item = request.form.get("item", "").strip()
        quantity = request.form.get("quantity", type=int)
        address = request.form.get("address", "").strip()
        pickup_date = request.form.get("pickup_date", "")
        notes = request.form.get("notes", "").strip()
        if not item or not quantity or quantity < 1 or not address or not pickup_date:
            flash("Please complete all required fields with a valid quantity.", "danger")
        else:
            with get_db() as db:
                db.execute("""INSERT INTO pickups
                    (user_id,item,quantity,address,pickup_date,notes,created_at)
                    VALUES(?,?,?,?,?,?,?)""",
                    (session["user_id"], item, quantity, address, pickup_date,
                     notes, datetime.now().strftime("%Y-%m-%d %H:%M")))
            flash("Your e-waste pickup request has been submitted.", "success")
            return redirect(url_for("dashboard"))
    return render_template("request_pickup.html")

@app.route("/admin")
@admin_required
def admin():
    with get_db() as db:
        rows = db.execute("""SELECT pickups.*, users.name AS customer, users.email
            FROM pickups JOIN users ON users.id=pickups.user_id ORDER BY pickups.id DESC""").fetchall()
        counts = {
            "total": db.execute("SELECT COUNT(*) FROM pickups").fetchone()[0],
            "pending": db.execute("SELECT COUNT(*) FROM pickups WHERE status='Pending'").fetchone()[0],
            "collected": db.execute("SELECT COUNT(*) FROM pickups WHERE status='Collected'").fetchone()[0],
            "recycled": db.execute("SELECT COUNT(*) FROM pickups WHERE status='Recycled'").fetchone()[0]
        }
    return render_template("admin.html", pickups=rows, counts=counts)

@app.route("/admin/update/<int:pickup_id>", methods=["POST"])
@admin_required
def update_status(pickup_id):
    status = request.form.get("status")
    if status in ["Pending", "Scheduled", "Collected", "Recycled"]:
        with get_db() as db:
            db.execute("UPDATE pickups SET status=? WHERE id=?", (status, pickup_id))
        flash("Request status updated.", "success")
    return redirect(url_for("admin"))

@app.route("/centers")
def centers():
    return render_template("centers.html")

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
