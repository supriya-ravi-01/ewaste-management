# E-Waste Management System

A beginner-friendly web application built with Python Flask, SQLite, HTML and CSS.

## Features
- User registration and login
- Submit electronic-waste pickup requests
- View personal request history and status
- Admin dashboard with request statistics
- Admin can update requests: Pending, Scheduled, Collected, Recycled
- Information page for responsible e-waste disposal
- Passwords stored as secure hashes

## Requirements
- Python 3.9 or later
- pip

## Run on Windows
1. Extract the ZIP file.
2. Open Command Prompt in the extracted `ewaste_management_system` folder.
3. Create a virtual environment:
   `python -m venv venv`
4. Activate it:
   `venv\\Scripts\\activate`
5. Install dependencies:
   `pip install -r requirements.txt`
6. Start the application:
   `python app.py`
7. Open `http://127.0.0.1:5000` in your browser.

The SQLite database (`ewaste.db`) is created automatically on first run.

## Admin login
- Email: `admin@ewaste.local`
- Password: `Admin@123`

Change the default password and Flask secret key before deploying publicly.

## Main folder structure
```
ewaste_management_system/
|-- app.py
|-- requirements.txt
|-- README.md
|-- templates/
|   |-- base.html
|   |-- index.html
|   |-- login.html
|   |-- register.html
|   |-- dashboard.html
|   |-- request_pickup.html
|   |-- admin.html
|   |-- centers.html
|-- static/
    |-- style.css
```

## Suggested future enhancements
- Email/SMS pickup notifications
- Map-based recycling-center locator
- Image upload for waste items
- QR code tracking
- Reports and charts for collected/recycled quantities
